from django.shortcuts import render
from django.http import HttpResponse


def home(request):
    context = {
        # Elimina cualquier línea como:
        # 'user_photo': user.profile.photo,
        # O coméntala:
        # 'user_photo': None,
    }
    return render(request, 'home.html', context)