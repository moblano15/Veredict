from django.contrib.auth.models import AbstractUser
from django.db import models

class Usuario(AbstractUser):
    # Campos personalizados
    avatar = models.ImageField(
        upload_to='avatars/', 
        null=True, 
        blank=True,
        verbose_name='Foto de perfil'
    )
    fecha_registro = models.DateTimeField(
        auto_now_add=True,
        verbose_name='Fecha de registro'
    )
    bio = models.TextField(
        max_length=500, 
        blank=True, 
        verbose_name='Biografía'
    )
    ubicacion = models.CharField(
        max_length=100, 
        blank=True, 
        verbose_name='Ubicación'
    )
    
    # Campos para resolver el conflicto de related_name
    groups = models.ManyToManyField(
        'auth.Group',
        verbose_name='groups',
        blank=True,
        help_text='The groups this user belongs to.',
        related_name="usuario_set",  # ¡ESTO ES IMPORTANTE!
        related_query_name="usuario",
    )
    
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        verbose_name='user permissions',
        blank=True,
        help_text='Specific permissions for this user.',
        related_name="usuario_set",  # ¡ESTO ES IMPORTANTE!
        related_query_name="usuario",
    )
    
    class Meta:
        verbose_name = 'Usuario'
        verbose_name_plural = 'Usuarios'
        db_table = 'usuarios_usuario'  # Nombre específico para la tabla
    
    def __str__(self):
        return self.username
    
    @property
    def nombre_completo(self):
        """Devuelve el nombre completo del usuario"""
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.username