import React, { useState } from 'react';
import '../styles.css';

const Header = ({ currentUser, onLogout, onNavigate, activeSection }) => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const handleNavigation = (section) => {
    onNavigate(section);
    setMenuOpen(false); // Cerrar menú en móvil
  };

  return (
    <header>
      <div className="container">
        <div className="header-content">
          {/* Logo más pequeño */}
          <img 
            src="/images/logo2.png" 
            alt="Veredict" 
            className="logo-img"
            style={{ width: '180px', height: 'auto' }}
          />
          
          {/* Menú Hamburguesa */}
          <div 
            className={`menu-toggle ${menuOpen ? 'active' : ''}`} 
            id="menu-toggle"
            onClick={toggleMenu}
          >
            <span></span>
            <span></span>
            <span></span>
          </div>

          {/* Navegación */}
          <nav id="main-nav" className={menuOpen ? 'active' : ''}>
            <ul>
              <li>
                <a 
                  href="#inicio" 
                  className={`nav-link ${activeSection === 'inicio' ? 'active' : ''}`}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavigation('inicio');
                  }}
                >
                  Inicio
                </a>
              </li>
              <li>
                <a 
                  href="#busqueda" 
                  className={`nav-link ${activeSection === 'busqueda' ? 'active' : ''}`}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavigation('busqueda');
                  }}
                >
                  Búsqueda
                </a>
              </li>
              <li>
                <a 
                  href="#crear" 
                  className={`nav-link ${activeSection === 'crear' ? 'active' : ''}`}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavigation('crear');
                  }}
                >
                  Crear
                </a>
              </li>
              <li>
                <a 
                  href="#perfil" 
                  className={`nav-link ${activeSection === 'perfil' ? 'active' : ''}`}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavigation('perfil');
                  }}
                >
                  Perfil
                </a>
              </li>
            </ul>
          </nav>
          
          <div className="user-actions">
            {currentUser ? (
              <>
                <span style={{ color: 'white', marginRight: '10px' }}>
                  Hola, {currentUser.name}
                </span>
                <a href="#" onClick={onLogout}>Cerrar Sesión</a>
                <div className="user-avatar" id="user-avatar">
                  <img src={currentUser.avatar || "https://via.placeholder.com/40"} alt="Usuario" />
                  <div className="edit-overlay">👤</div>
                </div>
              </>
            ) : (
              <a href="#" id="auth-link" onClick={(e) => {
                e.preventDefault();
                handleNavigation('auth');
              }}>
                Iniciar Sesión
              </a>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;