import React, { useState } from 'react';

const AuthModal = ({ onClose, onLogin }) => {
  const [activeTab, setActiveTab] = useState('login');
  const [formData, setFormData] = useState({
    loginEmail: '',
    loginPassword: '',
    registerName: '',
    registerEmail: '',
    registerPassword: '',
    registerConfirmPassword: ''
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleLogin = (e) => {
    e.preventDefault();
    
    // Simulación de login
    const user = {
      id: 1,
      name: "Usuario Demo",
      email: formData.loginEmail,
      avatar: "https://i.pravatar.cc/40?img=1",
      bio: "Nuevo usuario de Veredict",
      posts: 0,
      likes: 0,
      followers: 0
    };
    
    onLogin(user);
  };

  const handleRegister = (e) => {
    e.preventDefault();
    
    if (formData.registerPassword !== formData.registerConfirmPassword) {
      alert('Las contraseñas no coinciden');
      return;
    }
    
    const user = {
      id: Date.now(),
      name: formData.registerName,
      email: formData.registerEmail,
      avatar: `https://i.pravatar.cc/40?img=${Math.floor(Math.random() * 70) + 1}`,
      bio: "Nuevo usuario de Veredict",
      posts: 0,
      likes: 0,
      followers: 0
    };
    
    onLogin(user);
  };

  return (
    <div className="modal" style={{ display: 'flex' }}>
      <div className="modal-content">
        <div className="modal-header">
          <img src="/images/logo2.png" alt="Veredict" className="modal-logo-img" />
        </div>
        
        <div className="auth-tabs">
          <div 
            className={`auth-tab ${activeTab === 'login' ? 'active' : ''}`}
            onClick={() => setActiveTab('login')}
          >
            Iniciar Sesión
          </div>
          <div 
            className={`auth-tab ${activeTab === 'register' ? 'active' : ''}`}
            onClick={() => setActiveTab('register')}
          >
            Registrarse
          </div>
        </div>
        
        {/* Formulario de login */}
        {activeTab === 'login' && (
          <form id="login-form" className="auth-form veredict-form active" onSubmit={handleLogin}>
            <div className="form-group">
              <label htmlFor="loginEmail">E-mail *</label>
              <input 
                type="email" 
                id="loginEmail" 
                className="form-control" 
                placeholder="ejemplo@correo.com" 
                value={formData.loginEmail}
                onChange={handleChange}
                required 
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="loginPassword">Contraseña *</label>
              <input 
                type="password" 
                id="loginPassword" 
                className="form-control" 
                placeholder="Ingresa tu contraseña" 
                value={formData.loginPassword}
                onChange={handleChange}
                required 
              />
            </div>
            
            <button type="submit" className="veredict-btn">
              <span>🔑</span> Iniciar Sesión
            </button>
            
            <div className="divider">
              <span className="divider-text">O usa cuenta demo</span>
            </div>
            
            <button 
              type="button" 
              className="veredict-btn btn-secondary"
              onClick={() => {
                const demoUser = {
                  id: 1,
                  name: "Usuario Demo",
                  email: "demo@veredict.com",
                  avatar: "https://i.pravatar.cc/40?img=1",
                  bio: "Usuario de demostración",
                  posts: 3,
                  likes: 24,
                  followers: 12
                };
                onLogin(demoUser);
              }}
            >
              <span>👤</span> Usar Cuenta Demo
            </button>
          </form>
        )}
        
        {/* Formulario de registro */}
        {activeTab === 'register' && (
          <form id="register-form" className="auth-form veredict-form" onSubmit={handleRegister}>
            <div className="form-group">
              <label htmlFor="registerName">Nombre completo *</label>
              <input 
                type="text" 
                id="registerName" 
                className="form-control" 
                placeholder="Tu nombre" 
                value={formData.registerName}
                onChange={handleChange}
                required 
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="registerEmail">Correo electrónico *</label>
              <input 
                type="email" 
                id="registerEmail" 
                className="form-control" 
                placeholder="tu@email.com" 
                value={formData.registerEmail}
                onChange={handleChange}
                required 
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="registerPassword">Contraseña *</label>
              <input 
                type="password" 
                id="registerPassword" 
                className="form-control" 
                placeholder="Mínimo 6 caracteres" 
                value={formData.registerPassword}
                onChange={handleChange}
                required 
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="registerConfirmPassword">Confirmar Contraseña *</label>
              <input 
                type="password" 
                id="registerConfirmPassword" 
                className="form-control" 
                placeholder="Repite tu contraseña" 
                value={formData.registerConfirmPassword}
                onChange={handleChange}
                required 
              />
            </div>
            
            <button type="submit" className="veredict-btn">Registrarse</button>
          </form>
        )}
        
        <button 
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '15px',
            right: '15px',
            background: 'none',
            border: 'none',
            fontSize: '24px',
            cursor: 'pointer',
            color: '#666'
          }}
        >
          ×
        </button>
      </div>
    </div>
  );
};

export default AuthModal;