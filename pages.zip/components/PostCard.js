import React, { useState } from 'react';
import ShareModal from './ShareModal';

const PostCard = ({ post, currentUser, onLike, onAddComment }) => {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [showShareModal, setShowShareModal] = useState(false);

  const handleLike = () => {
    onLike(post.id);
  };

  const handleAddComment = (e) => {
    e.preventDefault();
    if (commentText.trim()) {
      onAddComment(post.id, commentText);
      setCommentText('');
    }
  };

  const renderStars = (rating) => {
    return '★'.repeat(rating) + '☆'.repeat(5 - rating);
  };

  return (
    <>
      <div className="post-card" data-post-id={post.id} data-category={post.category}>
        <div className="post-header">
          <div className="post-avatar">
            <img src={post.userAvatar} alt={post.userName} />
          </div>
          <div>
            <div className="post-user">{post.userName}</div>
            <div className="post-time">{post.time}</div>
          </div>
        </div>
        
        <div className="post-content">
          <span className="component-tag">{post.category.toUpperCase()}</span>
          <h3>{post.title}</h3>
          <div className="rating">{renderStars(post.rating)}</div>
          <p>{post.content}</p>
        </div>
        
        <div className="post-actions">
          <div 
            className={`post-action ${post.userLiked ? 'active' : ''}`} 
            onClick={handleLike}
            style={{ cursor: 'pointer' }}
          >
            <span>👍</span>
            <span className="like-count">{post.likes}</span>
          </div>
          
          <div 
            className="post-action" 
            onClick={() => setShowComments(!showComments)}
            style={{ cursor: 'pointer' }}
          >
            <span>💬</span>
            <span>Comentar ({post.comments.length})</span>
          </div>
          
          <div 
            className="post-action" 
            onClick={() => setShowShareModal(true)}
            style={{ cursor: 'pointer' }}
          >
            <span>🔄</span>
            <span>Compartir</span>
          </div>
        </div>
        
        {/* Sección de comentarios */}
        {showComments && (
          <div className="comments-section">
            <div className="comments-container">
              {post.comments.length > 0 ? (
                post.comments.map(comment => (
                  <div className="comment" key={comment.id}>
                    <div className="comment-header">
                      <div className="comment-avatar">
                        <img src={comment.userAvatar} alt={comment.userName} />
                      </div>
                      <div className="comment-user">{comment.userName}</div>
                      <div className="comment-time">{comment.time}</div>
                    </div>
                    <div className="comment-content">{comment.content}</div>
                  </div>
                ))
              ) : (
                <p style={{ textAlign: 'center', color: '#718096', padding: '20px' }}>
                  No hay comentarios todavía. ¡Sé el primero en comentar!
                </p>
              )}
            </div>
            
            {currentUser ? (
              <form className="comment-form" onSubmit={handleAddComment}>
                <input
                  type="text"
                  className="comment-input"
                  placeholder="Escribe tu comentario..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  required
                />
                <button type="submit" className="comment-btn">
                  Comentar
                </button>
              </form>
            ) : (
              <p style={{ textAlign: 'center', color: '#f4630c', padding: '10px' }}>
                <a href="#" style={{ textDecoration: 'underline' }}>Inicia sesión</a> para comentar
              </p>
            )}
          </div>
        )}
      </div>
      
      {/* Modal de compartir */}
      {showShareModal && (
        <ShareModal
          postId={post.id}
          onClose={() => setShowShareModal(false)}
        />
      )}
    </>
  );
};

export default PostCard;