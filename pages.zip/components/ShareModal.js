import React, { useState } from 'react';

const ShareModal = ({ postId, onClose }) => {
  const [copySuccess, setCopySuccess] = useState(false);
  
  const shareUrl = `${window.location.origin}/post/${postId}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const shareOptions = [
    { type: 'facebook', icon: '📘', label: 'Facebook' },
    { type: 'twitter', icon: '🐦', label: 'Twitter' },
    { type: 'linkedin', icon: '💼', label: 'LinkedIn' },
    { type: 'whatsapp', icon: '📱', label: 'WhatsApp' },
    { type: 'email', icon: '✉️', label: 'Email' }
  ];

  const handleShare = (type) => {
    let shareUrl = '';
    
    switch(type) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=Mira esta opinión en Veredict`;
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=Mira esta opinión en Veredict: ${encodeURIComponent(shareUrl)}`;
        break;
      case 'email':
        shareUrl = `mailto:?subject=Mira esta opinión en Veredict&body=${encodeURIComponent(shareUrl)}`;
        break;
    }
    
    if (type === 'email') {
      window.location.href = shareUrl;
    } else {
      window.open(shareUrl, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="share-modal" style={{ display: 'flex' }}>
      <div className="share-modal-content">
        <div className="share-modal-header">
          <div className="share-modal-title">Compartir publicación</div>
          <button className="close-share-modal" onClick={onClose}>
            ×
          </button>
        </div>
        
        <div className="share-options">
          {shareOptions.map(option => (
            <div
              key={option.type}
              className="share-option"
              onClick={() => handleShare(option.type)}
            >
              <span>{option.icon}</span>
              <span>{option.label}</span>
            </div>
          ))}
        </div>
        
        <div className="share-link-container">
          <input
            type="text"
            className="share-link"
            value={shareUrl}
            readOnly
          />
          <button className="copy-link-btn" onClick={handleCopyLink}>
            Copiar
          </button>
        </div>
        
        {copySuccess && (
          <div className="copy-success">¡Enlace copiado al portapapeles!</div>
        )}
      </div>
    </div>
  );
};

export default ShareModal;