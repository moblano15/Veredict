import React, { useState, useRef, useEffect } from 'react';

const Chatbox = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { sender: "Asistente Veredict", text: "¡Hola! Soy tu asistente de inteligencia artificial especializado en hardware. ¿En qué puedo ayudarte hoy?", type: "received" }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    // Añadir mensaje del usuario
    const userMessage = { sender: "Tú", text: inputText, type: "sent" };
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Respuesta simulada del AI
    setTimeout(() => {
      setIsTyping(false);
      
      const responses = [
        "Para gaming, recomiendo el AMD Ryzen 7 7800X3D por su tecnología 3D V-Cache.",
        "La elección de GPU depende de tu resolución. Para 1440p: RTX 4070 Ti o AMD RX 7800 XT.",
        "Hoy recomiendo mínimo 16GB de RAM para gaming, 32GB para multitarea intensiva.",
        "Los NVMe PCIe 4.0 como Samsung 990 Pro ofrecen las mejores velocidades.",
        "Para CPUs de alto rendimiento, considera refrigeración líquida de 240mm o más."
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      
      const aiMessage = { 
        sender: "Asistente Veredict", 
        text: randomResponse, 
        type: "received" 
      };
      
      setMessages(prev => [...prev, aiMessage]);
    }, 1500);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <div className="chatbox-container">
      <div className="chatbox-toggle" onClick={() => setIsOpen(!isOpen)}>
        <span>💬</span>
      </div>
      
      {isOpen && (
        <div className="chatbox active">
          <div className="chatbox-header">
            <div className="chatbox-title">Asistente Veredict AI</div>
            <button className="close-chatbox" onClick={() => setIsOpen(false)}>
              ×
            </button>
          </div>
          
          <div className="chatbox-messages">
            {messages.map((msg, index) => (
              <div key={index} className={`message ${msg.type}`}>
                {msg.type === 'received' && (
                  <div className="message-sender">{msg.sender}</div>
                )}
                <div className="message-text">{msg.text}</div>
              </div>
            ))}
            
            {isTyping && (
              <div className="typing-indicator">
                <div className="typing-dot"></div>
                <div className="typing-dot"></div>
                <div className="typing-dot"></div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="chatbox-input">
            <input
              type="text"
              placeholder="Escribe tu pregunta sobre hardware..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
            />
            <button 
              className="send-message" 
              onClick={handleSendMessage}
              disabled={!inputText.trim()}
            >
              Enviar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbox;