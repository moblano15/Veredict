import React, { useState } from 'react';
import PostCard from '../components/PostCard';

const samplePosts = [
  // ... (mismos datos que en Home.js o puedes importarlos)
  {
    id: 4,
    userId: 4,
    userName: "Laura Sánchez",
    userAvatar: "https://i.pravatar.cc/40?img=4",
    component: "NVIDIA RTX 4090",
    category: "gpu",
    rating: 5,
    title: "NVIDIA RTX 4090 - Monstruo de rendimiento",
    content: "La mejor tarjeta gráfica del mercado. Maneja cualquier juego en 4K con tasas de refresco altísimas. DLSS 3 es revolucionario.",
    likes: 67,
    userLiked: false,
    comments: [],
    time: "Hace 4 horas"
  },
  {
    id: 5,
    userId: 5,
    userName: "David López",
    userAvatar: "https://i.pravatar.cc/40?img=5",
    component: "AMD Radeon RX 7900 XTX",
    category: "gpu",
    rating: 4,
    title: "AMD Radeon RX 7900 XTX - Competencia seria",
    content: "Excelente alternativa a las RTX 4000. Buen rendimiento en rasterizado, Ray Tracing mejorado.",
    likes: 41,
    userLiked: false,
    comments: [],
    time: "Hace 1 día"
  }
];

const categories = [
  { id: 'all', name: 'Todos' },
  { id: 'cpu', name: 'CPU' },
  { id: 'gpu', name: 'GPU' },
  { id: 'ram', name: 'RAM' },
  { id: 'refrigeracion', name: 'Refrigeración' },
  { id: 'alimentacion', name: 'Fuente Alimentación' },
  { id: 'motherboard', name: 'Placa Base' },
  { id: 'storage', name: 'Almacenamiento' }
];

const Search = ({ currentUser }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [posts, setPosts] = useState(samplePosts);

  const filteredPosts = posts.filter(post => {
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    const matchesSearch = searchTerm === '' || 
      post.component.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesCategory && matchesSearch;
  });

  const handleLike = (postId) => {
    if (!currentUser) {
      alert("Debes iniciar sesión para dar me gusta");
      return;
    }
    
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const newLikeStatus = !post.userLiked;
        return {
          ...post,
          userLiked: newLikeStatus,
          likes: newLikeStatus ? post.likes + 1 : post.likes - 1
        };
      }
      return post;
    }));
  };

  const handleAddComment = (postId, commentText) => {
    if (!currentUser) {
      alert("Debes iniciar sesión para comentar");
      return;
    }
    
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const newComment = {
          id: post.comments.length + 1,
          userId: currentUser.id || 1,
          userName: currentUser.name || "Usuario",
          userAvatar: currentUser.avatar || "https://i.pravatar.cc/40",
          content: commentText,
          time: "Hace unos momentos"
        };
        
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    }));
  };

  return (
    <section id="busqueda" className="section">
      <h2>Buscar Componentes</h2>
      <div className="search-container">
        <input 
          type="text" 
          className="search-input" 
          placeholder="Buscar componentes, marcas, modelos..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button className="search-btn">
          Buscar
        </button>
      </div>
      
      <div className="category-buttons">
        {categories.map(category => (
          <button
            key={category.id}
            className={`category-btn ${selectedCategory === category.id ? 'active' : ''}`}
            onClick={() => setSelectedCategory(category.id)}
          >
            {category.name}
          </button>
        ))}
      </div>
      
      <h3>Resultados de búsqueda</h3>
      <div id="search-results">
        {filteredPosts.length > 0 ? (
          filteredPosts.map(post => (
            <PostCard
              key={post.id}
              post={post}
              currentUser={currentUser}
              onLike={handleLike}
              onAddComment={handleAddComment}
            />
          ))
        ) : (
          <div className="info-message">
            <p>No se encontraron resultados para tu búsqueda. Intenta con otros términos o categorías.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default Search;