import React, { useState } from 'react';
import PostCard from '../components/PostCard';

// Datos de ejemplo de usuario
const sampleUser = {
  id: 1,
  name: "Carlos Rodríguez",
  email: "carlos@veredict.com",
  avatar: "https://i.pravatar.cc/100?img=1",
  bio: "Entusiasta del hardware y overclocking",
  posts: 8,
  likes: 156,
  followers: 342
};

const userPosts = [
  {
    id: 1,
    userId: 1,
    userName: "Carlos Rodríguez",
    userAvatar: "https://i.pravatar.cc/40?img=1",
    component: "AMD Ryzen 7 7800X3D",
    category: "cpu",
    rating: 5,
    title: "AMD Ryzen 7 7800X3D - Bestia para gaming",
    content: "Increíble procesador para gaming...",
    likes: 45,
    userLiked: false,
    comments: [],
    time: "Hace 2 horas"
  }
];

const Profile = ({ currentUser }) => {
  const [user, setUser] = useState(currentUser || sampleUser);
  const [posts, setPosts] = useState(userPosts);
  const [isEditing, setIsEditing] = useState(false);
  const [editBio, setEditBio] = useState(user.bio || '');

  const handleSaveBio = () => {
    setUser(prev => ({
      ...prev,
      bio: editBio
    }));
    setIsEditing(false);
  };

  const handleLike = (postId) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const newLikeStatus = !post.userLiked;
        return {
          ...post,
          userLiked: newLikeStatus,
          likes: newLikeStatus ? post.likes + 1 : post.likes - 1
        };
      }
      return post;
    }));
  };

  const handleAddComment = (postId, commentText) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const newComment = {
          id: post.comments.length + 1,
          userId: user.id,
          userName: user.name,
          userAvatar: user.avatar,
          content: commentText,
          time: "Hace unos momentos"
        };
        
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    }));
  };

  if (!currentUser) {
    return (
      <section id="perfil" className="section">
        <div className="profile-header">
          <div className="profile-avatar">
            <img src="https://i.pravatar.cc/100" alt="Usuario" />
          </div>
          <div className="profile-info">
            <h1>Inicia sesión para ver tu perfil</h1>
            <div className="profile-stats">
              <div className="stat">
                <div className="stat-value">0</div>
                <div className="stat-label">Opiniones</div>
              </div>
              <div className="stat">
                <div className="stat-value">0</div>
                <div className="stat-label">Me gusta</div>
              </div>
              <div className="stat">
                <div className="stat-value">0</div>
                <div className="stat-label">Seguidores</div>
              </div>
            </div>
          </div>
        </div>
        <h2>Tus Opiniones</h2>
        <div id="user-posts">
          <p>Inicia sesión para ver y crear tus opiniones.</p>
        </div>
      </section>
    );
  }

  return (
    <section id="perfil" className="section">
      <div className="profile-header">
        <div className="profile-avatar">
          <img src={user.avatar} alt={user.name} />
        </div>
        <div className="profile-info">
          <h1>{user.name}</h1>
          
          {isEditing ? (
            <div style={{ marginBottom: '15px' }}>
              <textarea
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
                className="form-control"
                rows="3"
                placeholder="Escribe tu biografía..."
              />
              <div style={{ marginTop: '10px' }}>
                <button onClick={handleSaveBio} className="btn" style={{ marginRight: '10px' }}>
                  Guardar
                </button>
                <button onClick={() => setIsEditing(false)} className="btn btn-secondary">
                  Cancelar
                </button>
              </div>
            </div>
          ) : (
            <>
              <p>{user.bio}</p>
              <button 
                onClick={() => setIsEditing(true)}
                style={{
                  background: 'none',
                  border: '1px solid #f4630c',
                  color: '#f4630c',
                  padding: '5px 15px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  marginTop: '10px'
                }}
              >
                Editar biografía
              </button>
            </>
          )}
          
          <div className="profile-stats">
            <div className="stat">
              <div className="stat-value">{user.posts}</div>
              <div className="stat-label">Opiniones</div>
            </div>
            <div className="stat">
              <div className="stat-value">{user.likes}</div>
              <div className="stat-label">Me gusta</div>
            </div>
            <div className="stat">
              <div className="stat-value">{user.followers}</div>
              <div className="stat-label">Seguidores</div>
            </div>
          </div>
        </div>
      </div>
      
      <h2>Tus Opiniones</h2>
      <div id="user-posts">
        {posts.length > 0 ? (
          posts.map(post => (
            <PostCard
              key={post.id}
              post={post}
              currentUser={currentUser}
              onLike={handleLike}
              onAddComment={handleAddComment}
            />
          ))
        ) : (
          <p>Aún no has publicado ninguna opinión.</p>
        )}
      </div>
    </section>
  );
};

export default Profile;