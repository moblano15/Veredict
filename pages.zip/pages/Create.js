import React, { useState } from 'react';

const Create = ({ currentUser }) => {
  const [formData, setFormData] = useState({
    componente: '',
    categoria: '',
    valoracion: '',
    titulo: '',
    contenido: ''
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!currentUser) {
      alert("Debes iniciar sesión para crear una opinión");
      return;
    }
    
    if (!formData.componente || !formData.categoria || !formData.valoracion || 
        !formData.titulo || !formData.contenido) {
      alert('Por favor, completa todos los campos.');
      return;
    }
    
    // Aquí normalmente enviarías los datos a una API
    console.log('Nueva opinión:', formData);
    alert('¡Opinión creada exitosamente!');
    
    // Resetear formulario
    setFormData({
      componente: '',
      categoria: '',
      valoracion: '',
      titulo: '',
      contenido: ''
    });
  };

  if (!currentUser) {
    return (
      <section id="crear" className="section">
        <div className="form-container">
          <h2>Crear Nueva Opinión</h2>
          <div className="info-message">
            <p>Debes <a href="#" style={{ color: '#f4630c' }}>iniciar sesión</a> para crear una opinión.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="crear" className="section">
      <h2>Crear Nueva Opinión</h2>
      <div className="form-container">
        <form id="nueva-opinion" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="componente">Componentes</label>
            <input 
              type="text" 
              id="componente" 
              className="form-control" 
              placeholder="Ej: NVIDIA RTX 4070" 
              value={formData.componente}
              onChange={handleChange}
              required 
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="categoria">Categoría</label>
            <select 
              id="categoria" 
              className="form-control" 
              value={formData.categoria}
              onChange={handleChange}
              required
            >
              <option value="">Selecciona una categoría</option>
              <option value="cpu">CPU/Procesador</option>
              <option value="gpu">GPU/Tarjeta Gráfica</option>
              <option value="ram">RAM/Memoria</option>
              <option value="motherboard">Placa Base</option>
              <option value="storage">Almacenamiento</option>
              <option value="cooling">Refrigeración</option>
              <option value="psu">Fuente de Alimentación</option>
              <option value="case">Caja/Gabinete</option>
            </select>
          </div>
          
          <div className="form-group">
            <label htmlFor="valoracion">Valoración</label>
            <select 
              id="valoracion" 
              className="form-control" 
              value={formData.valoracion}
              onChange={handleChange}
              required
            >
              <option value="">Selecciona una valoración</option>
              <option value="5">★★★★★ - Excelente</option>
              <option value="4">★★★★☆ - Muy Bueno</option>
              <option value="3">★★★☆☆ - Bueno</option>
              <option value="2">★★☆☆☆ - Regular</option>
              <option value="1">★☆☆☆☆ - Malo</option>
            </select>
          </div>
          
          <div className="form-group">
            <label htmlFor="titulo">Título de la opinión</label>
            <input 
              type="text" 
              id="titulo" 
              className="form-control" 
              placeholder="Un título descriptivo para tu opinión" 
              value={formData.titulo}
              onChange={handleChange}
              required 
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="contenido">Tu opinión</label>
            <textarea 
              id="contenido" 
              className="form-control" 
              placeholder="Describe tu experiencia con el componente, puntos fuertes, débiles, etc." 
              rows="5"
              value={formData.contenido}
              onChange={handleChange}
              required
            ></textarea>
          </div>
          
          <button type="submit" className="btn">
            Publicar Opinión
          </button>
        </form>
      </div>
    </section>
  );
};

export default Create;