import React, { useState } from 'react';
import PostCard from '../components/PostCard';

// Datos de ejemplo
const samplePosts = [
  {
    id: 1,
    userId: 1,
    userName: "Carlos Rodríguez",
    userAvatar: "https://i.pravatar.cc/40?img=1",
    component: "AMD Ryzen 7 7800X3D",
    category: "cpu",
    rating: 5,
    title: "AMD Ryzen 7 7800X3D - Bestia para gaming",
    content: "Increíble procesador para gaming. La tecnología 3D V-Cache hace maravillas en juegos que dependen mucho de la caché. Temperaturas controladas con buen refrigerador. Consumo eficiente para el rendimiento que ofrece.",
    likes: 45,
    userLiked: false,
    comments: [
      {
        id: 1,
        userId: 2,
        userName: "Ana Martínez",
        userAvatar: "https://i.pravatar.cc/40?img=2",
        content: "¡Totalmente de acuerdo! Lo tengo desde hace 2 meses y es increíble para gaming.",
        time: "Hace 1 hora"
      }
    ],
    time: "Hace 2 horas"
  },
  {
    id: 2,
    userId: 2,
    userName: "Ana Martínez",
    userAvatar: "https://i.pravatar.cc/40?img=2",
    component: "Intel Core i9-14900K",
    category: "cpu",
    rating: 4,
    title: "Intel Core i9-14900K - Potencia extrema",
    content: "Rendimiento brutal en aplicaciones de productividad y gaming. Necesita refrigeración líquida de alta gama para mantener temperaturas bajo control. Consumo elevado pero justificado por el rendimiento.",
    likes: 32,
    userLiked: false,
    comments: [],
    time: "Hace 1 día"
  }
];

const Home = ({ currentUser }) => {
  const [posts, setPosts] = useState(samplePosts);

  const handleLike = (postId) => {
    if (!currentUser) {
      alert("Debes iniciar sesión para dar me gusta");
      return;
    }
    
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const newLikeStatus = !post.userLiked;
        return {
          ...post,
          userLiked: newLikeStatus,
          likes: newLikeStatus ? post.likes + 1 : post.likes - 1
        };
      }
      return post;
    }));
  };

  const handleAddComment = (postId, commentText) => {
    if (!currentUser) {
      alert("Debes iniciar sesión para comentar");
      return;
    }
    
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const newComment = {
          id: post.comments.length + 1,
          userId: currentUser.id || 1,
          userName: currentUser.name || "Usuario",
          userAvatar: currentUser.avatar || "https://i.pravatar.cc/40",
          content: commentText,
          time: "Hace unos momentos"
        };
        
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    }));
  };

  return (
    <section id="inicio" className="section active">
      <h2>Opiniones Recientes</h2>
      
      <div className="info-message">
        <p><strong>Resumen de componentes más populares</strong> - En esta sección encontrarás las opiniones más recientes sobre CPU, GPU y RAM.</p>
      </div>
      
      <div id="posts-container">
        {posts.length > 0 ? (
          posts.map(post => (
            <PostCard
              key={post.id}
              post={post}
              currentUser={currentUser}
              onLike={handleLike}
              onAddComment={handleAddComment}
            />
          ))
        ) : (
          <p>No hay publicaciones recientes.</p>
        )}
      </div>
    </section>
  );
};

export default Home;